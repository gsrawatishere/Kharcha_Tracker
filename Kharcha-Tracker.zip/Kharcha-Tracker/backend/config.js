const JWT_SECRET = "123456"
module.exports = {JWT_SECRET}