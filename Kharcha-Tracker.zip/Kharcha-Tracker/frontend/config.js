export const cnString = "http://localhost:4000/api/v1/user/"
